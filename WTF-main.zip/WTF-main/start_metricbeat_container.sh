#!/bin/bash
HOSTNAME=$(hostname)
docker start "metricbeat_${HOSTNAME}"