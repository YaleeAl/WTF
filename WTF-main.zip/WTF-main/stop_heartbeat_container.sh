#!/bin/bash
HOSTNAME=$(hostname)
docker stop "heartbeat_${HOSTNAME}"