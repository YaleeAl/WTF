#!/bin/bash
HOSTNAME=$(hostname)
docker stop "metricbeat_${HOSTNAME}"