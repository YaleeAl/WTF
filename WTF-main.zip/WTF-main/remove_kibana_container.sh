#!/bin/bash
HOSTNAME=$(hostname)
d=$(date +"%d%m%Y%H%M")
docker stop "kibana_${HOSTNAME}"
docker rm "kibana_${HOSTNAME}"
