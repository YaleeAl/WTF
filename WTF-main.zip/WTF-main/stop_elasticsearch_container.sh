#!/bin/bash
HOSTNAME=$(hostname)
docker stop "elasticsearch_${HOSTNAME}"