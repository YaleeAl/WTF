#!/bin/bash
HOSTNAME=$(hostname)
docker start "elasticsearch_${HOSTNAME}"