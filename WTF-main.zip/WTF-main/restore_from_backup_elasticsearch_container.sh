#!/bin/bash
h=$(hostname)
d=$(date +"%d%m%Y%H%M")
/root/stop_es.sh
cd /home/elasticsearch
file=$(cat last_backup.txt)
tar xvfpz ${file} -C .
chown -R 2000:2000 data
systemctl start elasticsearch
systemctl enable elasticsearch
mv -f /root/monitor_es_node.sh.bk /root/monitor_es_node.sh