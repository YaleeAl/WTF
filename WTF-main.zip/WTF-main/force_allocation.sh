# Get all unassigned shards
curl -u elastic:elastic -X GET "https://devops-srv-01:9200/_cat/shards?v" | grep "UNASSIGNED" | while read -r line; do
    # Extract index and shard info
    index=$(echo $line | awk '{print $1}')
    shard=$(echo $line | awk '{print $2}')
    
    # Allocate the replica for the shard to the current node (assumed to be devops-srv-01)
    curl -u elastic:elastic -X POST "https://devops-srv-01:9200/_cluster/reroute" -H 'Content-Type: application/json' -d "
    {
        \"commands\": [
            {
                \"allocate_replica\": {
                    \"index\": \"$index\",
                    \"shard\": $shard,
                    \"node\": \"devops-srv-02\"
                }
            }
        ]
    }"
done
