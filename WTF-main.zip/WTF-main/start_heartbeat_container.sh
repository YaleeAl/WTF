#!/bin/bash
HOSTNAME=$(hostname)
docker start "heartbeat_${HOSTNAME}"