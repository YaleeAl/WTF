#!/bin/bash
HOSTNAME=$(hostname)
docker stop "kibana_${HOSTNAME}"