#!/bin/bash
HOSTNAME=$(hostname)
d=$(date +"%d%m%Y%H%M")
docker stop "heartbeat_${HOSTNAME}"
docker rm "heartbeat_${HOSTNAME}"