#!/bin/bash
h=$(hostname)
d=$(date +"%d%m%Y%H%M")
mv -f /root/monitor_es_node.sh /root/monitor_es_node.sh.bk
systemctl stop elasticsearch
systemctl disable elasticsearch
cd /home/elasticsearch
tar cvfpz data.${d}.tar.gz data
echo "data.${d}.tar.gz" > last_backup.txt
mv -f docker_es_data docker_es_data.${d}
mv -f data docker_es_data
chown -R 1000:1000 docker_es_data
cd /root/elk-configs
cp -rf elasticsearch.yml elasticsearch.yml.bk
sed s/9201/9200/g -i elasticsearch.yml
sed s/9301/9300/g -i elasticsearch.yml