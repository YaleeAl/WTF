#!/bin/bash
HOSTNAME=$(hostname)
d=$(date +"%d%m%Y%H%M")
docker stop "elasticsearch_${HOSTNAME}"
docker rm "elasticsearch_${HOSTNAME}"