#!/bin/bash
HOSTNAME=$(hostname)
d=$(date +"%d%m%Y%H%M")
docker stop "metricbeat_${HOSTNAME}"
docker rm "metricbeat_${HOSTNAME}"