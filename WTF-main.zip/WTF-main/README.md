# ELK Stack Update Procedure

## Aim
The goal of this update procedure is to upgrade the current production version of the ELK stack to the latest stable version.

## Method
1. Install the current version of ELK on two testing servers.
2. Perform the update process on both servers.

## TL;DR
- Files are located at `devoptools/docker/elk` with run script for each.
- Ensure all components are updated to the same version.

---

## Elasticsearch

1. **Find the current stable version** of Elasticsearch:
   - Refer to the [Elasticsearch Docker documentation](https://www.elastic.co/guide/en/elasticsearch/reference/current/docker.html).

2. **SSH into testing servers:**
   - Server 1: `ssh root@devops-srv-01`
   - Server 2: `ssh root@devops-srv-02`

3. **Configuration files** for Elasticsearch are located in:  
   `/root/elk-configs`

4. **Run the Elasticsearch container on each of the two servers:**
   - It is important to run Elasticsearch on **both** servers for the setup to work.
   - Use the `run_elasticsearch_container.sh` script to start the container on each server.
   - If there is a problem with virtual memory -  https://stackoverflow.com/questions/41064572/docker-elk-vm-max-map-count

5. **Access Elasticsearch:**
   - URL: `https://server_ip:9200`

---

## Kibana

1. **SSH into the first server**:  
   `ssh root@devops-srv-01`

2. **Configuration files** for Kibana are located in:  
   `/root/elk-configs/kibana`

3. **Change the `kibana_system` user's password**:
   - In the Kibana configuration file `/root/elk-configs/kibana/kibana.yml`, update the password for the `kibana_system` user.

4. **Update the password** for the `kibana_system` user in Elasticsearch.
   Run the following curl command:
     ```bash
     curl -u elastic:elastic_password -X POST "https://localhost:9200/_security/user/kibana_system/_password" -H "Content-Type: application/json" -k -d '{ "password": "secure_new_password" }'
     ```

5. **Run the Kibana container**:
   - Use the `run_kibana_container.sh` script to start the Kibana container.

6. **Access Kibana**:
   - URL: `http://server_ip:5601`

---

## Notes
- Be sure to update all components (Elasticsearch, Kibana, etc.) to the same version for compatibility.
- The update process should be performed on testing servers first before applying to the production environment.
