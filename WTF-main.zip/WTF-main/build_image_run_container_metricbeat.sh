#!/bin/bash

# Define variables
HOSTNAME=$(hostname)
cwd=$(pwd)
image_name="metricbeat_image_${HOSTNAME}"
container_name="metricbeat_${HOSTNAME}"
elk_version="8.16.1"

# Step 1: Build the Docker image
docker build --build-arg METRICBEAT_VERSION="${elk_version}" -t "${image_name}:${elk_version}" "${cwd}"

# Step 2: Run the Docker container
docker run -d \
  --name "${container_name}" \
  --privileged \
  --volume /etc/resolv.conf:/etc/resolv.conf:ro \
  --volume /var/run/docker.sock:/var/run/docker.sock:ro \
  --volume /sys/fs/cgroup:/hostfs/sys/fs/cgroup:ro \
  --volume /proc:/hostfs/proc:ro \
  --volume /:/hostfs:ro \
  --restart unless-stopped \
  --network host \
  --user root \
  --workdir /usr/share/metricbeat \
  --env ELASTIC_CONTAINER=true \
  "${image_name}:${elk_version}"

echo "Metricbeat container '${container_name}' is running with version ${elk_version}."
