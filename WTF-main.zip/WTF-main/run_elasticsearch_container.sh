#!/bin/bash

elk_version="8.16.1"  # Define the Elasticsearch version as a variable
timezone="Asia/Jerusalem"

HOSTNAME=$(hostname)
cwd=$(pwd)

docker run -d \
  --net host \
  --name "elasticsearch_${HOSTNAME}" \
  -e "network.publish_host=${HOSTNAME}" \
  -e "node.name=${HOSTNAME}" \
  -e "node.attr.rack=node_${HOSTNAME}" \
  -e "path.repo=/home/elasticsearch/backup" \
  -e "ELASTIC_PASSWORD=elastic" \
  -e "TZ=${timezone}" \
  -v "${cwd}/jvm.options:/usr/share/elasticsearch/config/jvm.options" \
  -v "/home/elasticsearch/docker_es_data:/usr/share/elasticsearch/data" \
  -v "/home/elasticsearch/docker_es_backup:/home/elasticsearch/backup" \
  -v "${cwd}/elasticsearch.yml:/usr/share/elasticsearch/config/elasticsearch.yml" \
  -v "/opt/certs:/usr/share/elasticsearch/config/certificates" \
  --restart unless-stopped \
  "elasticsearch:${elk_version}"

  echo "Elasticsearch container elasticsearch_${HOSTNAME} is running with version ${elk_version}."
