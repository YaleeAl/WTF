#!/bin/bash

elk_version="8.16.1"  # Define the Elasticsearch version as a variable

HOSTNAME=$(hostname)
cwd=$(pwd)

docker run -d \
  --name "kibana_${HOSTNAME}" \
  --volume "${cwd}/kibana.yml:/usr/share/kibana/config/kibana.yml:ro" \
  --volume "/etc/localtime:/etc/localtime:ro" \
  --restart "unless-stopped" \
  --publish "5601:5601" \
  --user "1000" \
  --env "ELASTIC_CONTAINER=true" \
  "docker.elastic.co/kibana/kibana:${elk_version}"

  echo "Kibana container kibana_${HOSTNAME} is running with version ${elk_version}."
