#!/bin/bash
HOSTNAME=$(hostname)
docker start "kibana_${HOSTNAME}"