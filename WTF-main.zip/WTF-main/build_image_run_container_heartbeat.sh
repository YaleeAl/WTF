#!/bin/bash
HOSTNAME=$(hostname)
cwd=$(pwd)
image_name="heartbeat_image_${HOSTNAME}"
container_name="heartbeat_${HOSTNAME}"
timezone="Asia/Jerusalem"
elk_version="8.16.1"


# Step 1: Build the Docker image
docker build --build-arg HEARTBEAT_VERSION="${elk_version}" -t "${image_name}" "${cwd}"


# Step 2: Run the Docker container
docker run --restart=unless-stopped -d \
  --name "${container_name}" \
  -e "TZ=${timezone}" \
  "${image_name}"

echo "Heartbeat container heartbeat_test_image_${HOSTNAME} is running with version ${elk_version}."


